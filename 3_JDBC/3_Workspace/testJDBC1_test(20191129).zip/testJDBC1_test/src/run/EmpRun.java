package run;

import view.EmpView;

public class EmpRun {
	public static void main(String[] args) {
		EmpView view = new EmpView();
		view.mainMenu();
	}
}
